ad="tazven"

sonuc=len(ad) #Değişkenin karakter sayısını alma
print(sonuc)

sonuc=ad[0] #0. karakteri yazdırma
print(sonuc)

sonuc=ad[1:5] #1. karakterden 5. karaktere kadar yazma
print(sonuc)

sonuc=ad[1:5:2] #1. karakterden 5. karaktere kadar ikişerli yazma
print(sonuc)

sonuc=ad[::-1] #Tersten yazma
print(sonuc)