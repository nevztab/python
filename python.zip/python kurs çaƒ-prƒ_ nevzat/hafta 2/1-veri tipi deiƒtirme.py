x=15 #int veri tanımlama
print(type(x)) #x'in türünü yazdırma

x=str(x) #int veriyi str ye çevirme
print(type(x))