pi=22/7 #pi sayısı tanımlama (22/7=3.14)

r=int(input("Yarı çap giriniz: "))

cevre=2*pi*r #çevre hesaplama
alan=pi*r**2 #alan hesaplama

print(f"Dairenin alanı: {alan}, çevresi: {cevre}")