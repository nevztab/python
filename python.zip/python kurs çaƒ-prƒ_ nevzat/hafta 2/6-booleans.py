#OPERATÖR#
print(100==100) #Eşit mi?
print(10!=100)  #Eşit değil mi?
print(10<11)    #Büyük mü?
print(10>9)     #Küçükmü


#OR/AND/NOT#
print(9>10 or 10>9)       #9 10'dan büyükse veya 10 9'dan büyükse True
print(9>10 and 10>9)      #9 10'dan büyükse ve 10 9'dan büyükse True
print(not(9>10 and 10>9)) #9 10'dan büyükse ve 10 9'dan büyükse False
