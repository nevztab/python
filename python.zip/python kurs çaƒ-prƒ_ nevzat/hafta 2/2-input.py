isim=input("isminiz nedir?\n") #isim inputu alma
yas=int(input("yaşınız nedir?\n")) #str olarak alınan yaş verisini int e çevirme

print(f"hoş geldin {isim}, yaşınız {yas}")