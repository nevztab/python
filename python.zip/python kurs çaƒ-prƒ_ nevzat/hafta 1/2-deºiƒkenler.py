#-----------------deiğşkenler-------------------------#

ad = 'Nevzat' #(') ile string veri
sınıf = "10-D" #(") ile string veri
okulNo=3040 #integer veri
boy=1.80 #float veri
erkekMi=True #bool veri

#-----------------deiğşkenler-------------------------#

