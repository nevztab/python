# 0değiş ken = "hatalı deisken"
bubirdeişken = "raconsuz deisken"
deisken = "dogru deisken"

print(deisken) #Yorum satırı

'''
çoklu
yorum
satırı
'''
