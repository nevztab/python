'''
#-----------------int-------------------------#

dogumYili=2006
tarih=2022

yas=tarih-dogumYili # tarihten doğum yılı çıkartarak yaş bulma

print(yas)

#-----------------int-------------------------#
'''

'''
#-----------------str-------------------------#

ad="Nevzat"
soyad="Ulaş"

isim=ad+' '+soyad #ad ile soyad arasına boşluk koyma

print(isim)

#-----------------str-------------------------#

'''

'''
#-----------------farklı veri-------------------------#

takım="kayseri spor"
sehir="kayseri"
puan=45
ortralamaGol=2.5


print("Takım: "+takım+" Şehir: "+sehir) # "+" ile birleştirme

print(takım+sehir+puan) #Hatalı kullanım

print("Takım: ",takım," puan: ",puan) # "," ile birleştirme

print("Takım: {}\nPuan: {}".format(takım,puan)) # "format" ile birleştirme

print(f"Takım: {takım}\n puan: {puan}") # "f" ile birleştirme



#-----------------farklı veri-------------------------#

'''

